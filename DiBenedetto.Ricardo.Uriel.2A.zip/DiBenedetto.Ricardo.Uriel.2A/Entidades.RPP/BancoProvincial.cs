﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class BancoProvincial : BancoNacional
    {
        public string provincia;
        public BancoProvincial(BancoNacional a , string prov):base(a._nombre, a.pais)
        {

        }

        public override string Mostrar(Banco a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine("provincia : " + this.provincia);
            return sb.ToString();
        }

        public override string Mostrar()
        {
            return this._nombre;
        }
    }
}
