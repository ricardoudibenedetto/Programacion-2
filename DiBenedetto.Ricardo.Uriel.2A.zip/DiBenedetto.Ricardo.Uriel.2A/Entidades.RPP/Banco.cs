﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public abstract class Banco
    {
       public string _nombre;
        public Banco(string nombre)
        {
            this._nombre = nombre;
        }
        //Agregar en Banco el método Mostrar():string y Mostrar(Banco):string, ambos abstractos.
        //El método que no recibe parámetros, retornará el nombre, mientras que el otro
        //retornará todas las características de la instancia que recibe como parametro. REUTILIZAR CODIGO.

        public abstract string Mostrar(Banco a);
        public abstract string Mostrar();

    }
}
