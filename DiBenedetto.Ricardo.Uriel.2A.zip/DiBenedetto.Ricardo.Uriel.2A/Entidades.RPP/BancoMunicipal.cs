﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class BancoMunicipal :BancoProvincial
    {
        public string municipio;

        public BancoMunicipal(BancoProvincial a , string muni ) :base(a ,a.provincia)
        {
            this.municipio = muni;
        }

        public override string Mostrar(Banco a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine("Municipio : " + this.municipio);
            return sb.ToString();
        }

        public override string Mostrar()
        {
            return this._nombre;
        }

        public static implicit operator string(BancoMunicipal p1)
        {
            
            return p1.Mostrar(p1);
           
        }
    }
}
