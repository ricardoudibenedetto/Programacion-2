﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class Deposito
    {
        public Producto[] productos;

        public Deposito (int cant )
        {
            this.productos = new Producto[cant];
        }
        public Deposito():this(3)
        {

        }


        public static Producto[] operator +(Deposito arr1 , Deposito arr2)
        {
            int acum = 0;
            acum += arr1.productos.Length;
            acum += arr2.productos.Length;

            Deposito arr3 = new Deposito(acum);
            for (int i = 0; i < arr1.productos.Length; i++)
            {
                arr3.productos[i] = arr1.productos[i];
            }
            for (int i = arr1.productos.Length; i < acum; i++)
            {
                arr3.productos[i] = arr2.productos[i];
            }
           
            return arr3.productos;
        }
    }
}
