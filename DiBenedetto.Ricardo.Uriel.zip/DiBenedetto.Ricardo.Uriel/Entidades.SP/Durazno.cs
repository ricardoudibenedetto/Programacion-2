using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SP
{
  //Durazno-> _cantPelusa:int (protegido); Nombre:string (prop. s/l, retornará 'Durazno'); 
  //Reutilizar FrutaToString en ToString() (mostrar todos los valores). TieneCarozo->true
  public class Durazno : Fruta
  {
    protected int _cantPelusa;
    public string Nombre { get { return "Durazno"; } }

    public override bool TieneCarozo { get { return true; } }

    public Durazno(string color , double peso , int cantpelu):base(color, peso)
    {
      this._cantPelusa = cantpelu;
    }

    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Cantidad de pelusa: " + this._cantPelusa);

      return sb.ToString();
    }

    public override string ToString()
    {
      return base.FrutaToString();
    }
  }
}
