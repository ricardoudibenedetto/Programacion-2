using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SP
{
  //Banana-> _paisOrigen:string (protegido); Nombre:string (prop. s/l, retornará 'Banana'); 
  //Reutilizar FrutaToString en ToString() (mostrar todos los valores). TieneCarozo->false
  public class Banana: Fruta
  {
    protected string _paisOrigen;
    public string Nombre { get { return "Banana"; } }

    public override bool TieneCarozo { get { return false; } }

    public Banana(string color, double peso, string paisOri ): base(color , peso)
    {
      this._paisOrigen = paisOri;
    }

    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Pais de origen: " + this._paisOrigen);

      return sb.ToString();
    }

    public override string ToString()
    {
      return base.FrutaToString();
    }
  }
}
