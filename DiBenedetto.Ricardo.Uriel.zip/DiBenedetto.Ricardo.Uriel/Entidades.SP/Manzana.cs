using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades.SP
{
  //Manzana-> _provinciaOrigen:string (protegido); Nombre:string (prop. s/l, retornará 'Manzana'); 
  //Reutilizar FrutaToString en ToString() (mostrar todos los valores). TieneCarozo->true
  public class Manzana : Fruta ,ISerializar , IDeserializar
  {
    protected string _provinciaOrigen;
    public string Nombre { get {return "Manzana"; }  }

    public override bool TieneCarozo { get { return true; } }
    public Manzana():this("roja", 2 , "catamarca")
    {
      
    }
    public Manzana(string color , double peso , string provOrigen):base(color, peso)
    {
      this._provinciaOrigen = provOrigen;
    }

    protected override string FrutaToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.FrutaToString());
      sb.AppendLine("Provincia de origen: " + this._provinciaOrigen);

      return sb.ToString();
    }

    public override string ToString()
    {
      return base.FrutaToString();
    }

    public bool Xml(string t)
    {
      bool flag = false;
      TextWriter escritor = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + t, true);
      try
      {
       XmlSerializer serializer = new XmlSerializer(typeof(Manzana));
       serializer.Serialize(escritor, this);
        flag = true;
      }
      catch (Exception)
      {
        escritor.Close();
        flag = false;
      }
     
      escritor.Close();
      return flag;
    }

    bool IDeserializar.xml(string t, out Fruta fru)
    {
      TextReader leer = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) +t, true);
      try
      {
        XmlSerializer deserializador = new XmlSerializer(typeof(Manzana));
        deserializador.Deserialize(leer);
        Fruta fruta = (Fruta)deserializador.Deserialize(leer);
        fru = fruta;
      }
      catch (Exception)
      {
        fru = null;
        leer.Close();
        return false;
       
      }
      
      leer.Close();
      return true;
    }
  }
}
