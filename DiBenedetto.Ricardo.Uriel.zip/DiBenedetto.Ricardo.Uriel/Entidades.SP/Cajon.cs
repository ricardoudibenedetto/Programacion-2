using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades.SP
{
  //Crear la clase Cajon<T>
  //atributos: _capacidad:int, _elementos:List<T> y _precioUnitario:double (todos protegidos)        
  //Propiedades
  //Elementos:(sólo lectura) expone al atributo de tipo List<T>.
  //PrecioTotal:(sólo lectura) retorna el precio total del cajón (precio * cantidad de elementos).
  //Constructor
  //Cajon(), Cajon(int), Cajon(int, double); 
  //El por default: es el único que se encargará de inicializar la lista.
  //Métodos
  
  
  
  public class Cajon <T> : ISerializar
  {
    protected int _capacidad;
    protected List<T> _elementos;
    protected double _precioUnitario;

    public List<T> Elementos { get { return this._elementos; } }

    public double PrecioTotal
    {
      get {
        
        return _precioUnitario * Elementos.Count  ;
      }
    }


    public Cajon()
    {
      this._elementos = new List<T>();
    }

    public Cajon(int capacidad) : this()
    {
      this._capacidad = capacidad;
    }

    public Cajon( double precio , int capacidad) : this(capacidad)
    {
      this._precioUnitario = precio;
    }

    //ToString: Mostrará en formato de tipo string, la capacidad, la cantidad total de elementos, el precio total 
    //y el listado de todos los elementos contenidos en el cajón. Reutilizar código.
    //Sobrecarga de operador
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Capacidad del cajon: " + this._capacidad);
      sb.AppendLine("Cantidad de elementos: " + this._elementos.Count);
      sb.AppendLine("Precio total: " + this._precioUnitario);
      foreach (T item in this._elementos)
      {
        sb.AppendLine(item.ToString());
      }

      return sb.ToString();
    }

    public bool Xml(string t)
    {
      bool flag = false;
      TextWriter escritor = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + t, true);
      try
      {
        XmlSerializer serializador = new XmlSerializer(typeof(Cajon<T>));
        
        serializador.Serialize(escritor, this);
       
        flag = true;
      }
      catch (Exception)
      {
        flag= false;
      }
      finally
      {
        escritor.Close();
      }
      return flag;
    }

    //(+) Será el encargado de agregar elementos al cajón, siempre y cuando no supere la capacidad del mismo.
    public static Cajon<T> operator +(Cajon<T> cajon, T fruta)
    {
      Cajon<T> cajon2 = new Cajon<T>();
      cajon2 = cajon;
      if (cajon._capacidad > cajon.Elementos.Count)
      {
        cajon._elementos.Add(fruta);
      }
      else
      {
        throw new CajonLlenoException("La capacidad llego a su limite");
      }

      return cajon2;
    }

  }
}
