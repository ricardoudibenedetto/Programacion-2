using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase10
{
    public class DepositoDeAutos
    {
    #region atributos
    int _capacidadMaxima;
    List<Auto> deposito;
    #endregion
    #region metodo
    public DepositoDeAutos(int capadidad)
    {
      this._capacidadMaxima = capadidad;
      this.deposito = new List<Auto>(capadidad);
    }

    public static bool operator +(DepositoDeAutos d , Auto a1)
    {
      bool flag = false;
      if(d.deposito.Count< d._capacidadMaxima)
      {
        d.deposito.Add(a1);
        flag = true;
      }
      return flag;
    }


    private int GetIndice(Auto a)
    {
      int flag = -1;
      int contadore=0;
      foreach(Auto item in this.deposito)
      {
        if(item == a)
        {
          flag = contadore;
          break;
        }

        contadore++;
      }
      return flag;
    }

    public static bool operator -(DepositoDeAutos d, Auto a1)
    {
      bool flag = false;
      int indice;
      indice = d.GetIndice(a1);
      if(indice != -1)
      {
        d.deposito.RemoveAt(indice);
        flag= true;
      }
      return flag;
    }

    public bool Agregar(Auto a)
    {
      
      return this + a;

    }

    public bool Remover(Auto a)
    {

      return this - a;

    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("capacidad : " + this._capacidadMaxima);
      foreach(Auto item in this.deposito)
      {
        sb.AppendLine(item.ToString());
      }
      return sb.ToString();
    }
    #endregion
  }
}
