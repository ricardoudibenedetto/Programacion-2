﻿using System;

namespace Entidades.clase10
{
    public class Class1
    {
    }
}
