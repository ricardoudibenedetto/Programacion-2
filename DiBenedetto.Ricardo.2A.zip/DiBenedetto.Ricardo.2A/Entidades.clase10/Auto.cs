using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase10
{
    public class Auto
    {
    #region atributos
    string _color;
    string _marca;

    #endregion

    #region propiedades
    public string Color { get { return _color; } }
    public string Marca { get { return _marca; } }

    #endregion

    #region metodos
    public Auto(string color , string marca)
    {
      this._color = color;
      this._marca = marca;
    }

    public static bool operator ==(Auto v1, Auto v2)
    {
      bool returnAux = false;
      if (string.Compare(v1._color,v2._color)==0 && string.Compare(v1._marca,v2._marca)==0)
      {
        returnAux = true;
      }
      return returnAux;
    }
    public static bool operator !=(Auto v1, Auto v2)
    {
      return !(v1 == v2);
    }

    public override bool Equals(object obj)
    {
      bool flag = false;
      if(obj is Auto && this==(Auto)obj)
      {
        flag = true;
      }
      return flag;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(this._marca + " " + this._color);
      return sb.ToString();
    }

    #endregion
  }
}
