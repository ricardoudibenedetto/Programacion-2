using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Persona;
using Entidades.Externa;
using Entidades.Externa.Sellada;
namespace ConsolePersona
{
  class Program
  {
    static void Main(string[] args)
    {
      Persona p1 = new Persona("camila", "posso", 23, ESexo.Femenino);

      //Console.WriteLine("Nombre: "+p1.Nombre + "  Apellido: " + p1.Apellido+ " Edad: "+ p1.Edad +" Sexo: "+ p1.Sexo);
      Console.WriteLine(p1.ObtenerDatos());
      
      
      PersonaExternaHeredadda p2 = new PersonaExternaHeredadda("Carlos ", "Mitta", 82, Entidades.Externa.ESexo.Masculino);
      PersonaExternaSellada p3 = new PersonaExternaSellada("Camila", "Posso", 23, Entidades.Externa.Sellada.ESexo.Femenino);
      Persona p = null;
     
      Console.WriteLine(p2.ObtenerDatos());
      //muestra los datos de una persona perteneciente a una clase sellada , utilizando Extencion de metodos
      Console.WriteLine(p3.ObtenerDatos());
      if (p.EsNulo())
      {
        Console.WriteLine("es nula ");
      }

      //dice si una Persona es nula
      if (p2.EsNulo())
      {
        Console.WriteLine("es nula ");
      }
      else
        Console.WriteLine("no es nulo");


      // retorna la cantidad de digitos de un numero 
      int i = 33;
      Console.WriteLine(i.CantidadDigitos());

      //tienen la misma cantidad 
      int a = 348;
      if (a.TieneLaMismaCantidad(5))
      {
        Console.WriteLine("tiene la misma cant");
      }
      else
        Console.WriteLine("no tiene la misma cantidad");

      //if (p1.AgregarDB())
      //{ Console.WriteLine("se agrego correctmente"); }
      //else
      //  Console.WriteLine("no se agrego");


      if (p1.quitarDB(34))
      { Console.WriteLine("se borro correctmente"); }
      else
        Console.WriteLine("no se borro");



      //if (p1.ModificarDB(7))
      //{ Console.WriteLine("se modifico correctmente"); }
      //else
      //  Console.WriteLine("no se modifico");


      List<Persona> personas = p.TraerDB();

      foreach (Persona item in personas)
      {
        Console.WriteLine(item.ObtenerDatos());
      }


      Console.ReadKey();

     
     
    }
  }
}
