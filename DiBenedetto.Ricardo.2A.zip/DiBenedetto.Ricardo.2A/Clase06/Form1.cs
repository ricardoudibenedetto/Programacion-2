using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase06
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    #region ATRIBUTO
    private clase05.Pluma _pluma;
    private clase05.Tinta _tinta;

    #endregion

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FrmTinta form = new FrmTinta();

      form.Show();
    }
  }
}
