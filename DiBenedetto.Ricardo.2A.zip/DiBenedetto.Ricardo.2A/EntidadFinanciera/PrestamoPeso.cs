﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadFinanciera
{
    class PrestamoPeso : Prestamo
    {
        protected float _porcentajeInteres;
        public PrestamoPeso(float monto, DateTime vencimiento , float interes ):base ( monto , vencimiento )
        {
            this._porcentajeInteres = interes;
        }
        public PrestamoPeso(Prestamo prestamo , float porcentajeInteres):this(prestamo.Monto,prestamo.Vencimiento,porcentajeInteres)
        {

        }

        public float Interes
        {
            get
            {
                return this.CalcularInteres();
            }
        }

        private float CalcularInteres()
        {
            float retorno = 0;
            retorno =(( _monto * this._porcentajeInteres)/100);
            return retorno;
        }
        public override void ExtenderPlazo(DateTime nuevoVencimiento)
        {
            DateTime fecha = this.Vencimiento;
            DateTime now = DateTime.Now;

            TimeSpan dias;

            dias = (now - fecha);
            float aumento = (float)(2.5 * dias.Days) / 100;
            this._porcentajeInteres += aumento;
            this.Vencimiento = DateTime.Now;

        }

        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.mostrar() + " " + this._porcentajeInteres + " "+ this.Interes);
            return sb.ToString();
        }
    }
}
