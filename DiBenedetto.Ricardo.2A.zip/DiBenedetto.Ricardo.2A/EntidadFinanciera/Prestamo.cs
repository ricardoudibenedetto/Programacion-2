﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadFinanciera
{
    public abstract class Prestamo
    {
        protected float _monto;
        protected DateTime _vencimiento;
        public DateTime Vencimiento {
            get { return this._vencimiento; }
            set { if(_vencimiento> DateTime.Now)
                    {
                    this._vencimiento = value;
                    }
                    else
                    {
                        this._vencimiento = DateTime.Now;
                    }
                }
        }

        public float Monto { get { return this._monto; }  }

        //constructor 

        public Prestamo(float monto, DateTime tiempo )
        {
            this._monto = monto;
            Vencimiento = tiempo; 
        }

        //metodo 

        public static int OrdenarPorFecha(Prestamo p1 , Prestamo p2)
        {
            int valor = 0;
            if (p1._vencimiento == p2._vencimiento)
            {
                valor = 0;
            }
            else
            {
                if(p1._vencimiento>p2._vencimiento)
                {
                    valor = 1;
                }
                else
                { valor = -1; }
            }
            return valor;
        }

        public abstract void ExtenderPlazo(DateTime nuevoVencimiento);

        public virtual string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("vencimiento : " + _vencimiento);
            sb.Append(" monto : " + _monto);

            return sb.ToString();
        }

     
       
    }
}
