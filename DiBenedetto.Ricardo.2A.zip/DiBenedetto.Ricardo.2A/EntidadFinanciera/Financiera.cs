﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadFinanciera
{
    class Financiera
    {
        private List<Prestamo> _listaDePrestamo;
        string razonSocial;



        private Financiera()
        {
            this._listaDePrestamo = new List<Prestamo>();
        }

        public Financiera(string razonsocial) : this()
        {
            this.razonSocial = razonsocial;

        }
        public float interesesEnDolares
         {
            get
            {
                float i=0;
                return i;
            }
         }
        //public explicit operator string(Financiera financiera)
        //{

        //    return 
        //}


    }
}
