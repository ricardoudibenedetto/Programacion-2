﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadFinanciera
{
    class PrestamoDolar : Prestamo
    {
       private PeriodicidadDePagos _periodicidad;
      
        public PeriodicidadDePagos Periodicidad { get { return this._periodicidad; } }

        //constructor
        public PrestamoDolar(float monto , DateTime vencimiento , PeriodicidadDePagos periodicidad) : base ( monto , vencimiento)
        {
            _periodicidad = periodicidad;
        }
        public PrestamoDolar(Prestamo prestamo, PeriodicidadDePagos Periodicidad) : this(prestamo.Monto, prestamo.Vencimiento, Periodicidad)
        {

        }
        //propiedad
        public float Interes
        {
            get
            {
                return this.CalcularInteres();
            }
        }

        //metodo
        private float CalcularInteres()
        {
            float retorno = 0;
            switch (Periodicidad)
            {
                case PeriodicidadDePagos.mensual:
                    retorno = (Monto * 25) / 100;
                    break;
                case PeriodicidadDePagos.bimestral:
                    retorno = (Monto * 35) / 100;
                    break;
                case PeriodicidadDePagos.trimestral:
                    retorno = (Monto * 40) / 100;
                    break;
                default:
                    break;
            }
            return retorno;
        }

        public override void ExtenderPlazo(DateTime nuevoVencimiento)
        {
            DateTime fecha = this.Vencimiento;
            DateTime now = DateTime.Now;

            TimeSpan dias;

            dias = (now - fecha);
            float aumento = (float)2.5 * dias.Days;
            this._monto += aumento;
            this.Vencimiento = DateTime.Now;

        }

        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.mostrar() + " " + this.Periodicidad+ " " + this.Interes);
            return sb.ToString();
        }
    }

}
