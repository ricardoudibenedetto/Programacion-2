﻿public enum PeriodicidadDePagos
{
    mensual,
    bimestral,
    trimestral
}