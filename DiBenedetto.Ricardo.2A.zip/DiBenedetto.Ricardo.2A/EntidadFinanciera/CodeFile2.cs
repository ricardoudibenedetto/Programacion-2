﻿public enum TipoDePrestamo
{
    pesos,
    dolares,
    todos
}