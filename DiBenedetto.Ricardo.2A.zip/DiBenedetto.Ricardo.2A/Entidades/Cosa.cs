using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{ 
  class Cosa
  {
    #region Atributos
    public string cadena;
    public double numero;
    public DateTime fecha;
    #endregion

    #region Metodos
    public static string Mostrar(Cosa a)
    {
      return a.Mostrar();
    }
    private string Mostrar()
    {
      return this.cadena + " " + this.numero.ToString() + " " + this.fecha.ToLongTimeString();
    }
    /// <summary>
    /// Establece el valor a la cadena
    /// </summary>
    /// <param name="a"></param>
    public void EstablelcerValor(string a)
    {
      this.cadena = a;
    }

    /// <summary>
    /// establece el valor para la fecha
    /// </summary>
    /// <param name="a"></param>
    public void EstablelcerValor(DateTime a)
    {
      this.fecha = a;
    }
    /// <summary>
    /// establece el valor para numero
    /// </summary>
    /// <param name="a"></param>
    public void EstablelcerValor(double a)
    {
      this.numero = a;
    }

    #endregion

    #region Constructor
    public Cosa()
    {
      this.cadena = "sin value";
      this.numero = 1.9;
      this.fecha = DateTime.Now;
    }
    public Cosa(string c)
    {
      this.cadena = c;
      this.numero = 1.9;
      this.fecha = DateTime.Now;
    }
    #endregion
  }
}
