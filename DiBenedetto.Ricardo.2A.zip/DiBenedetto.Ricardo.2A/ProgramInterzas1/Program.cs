using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.interfaz;
namespace ProgramInterzas1
{
  class Program
  {
    static void Main(string[] args)
    {
      Deportivo auto1 = new Deportivo(1000, "fntic", 8);
      Avion av1 = new Avion(200000, 600);
      Privado av2 = new Privado(200, 2000, 4000);
      Console.WriteLine(Gestion.MostrarImpuestoNacional(auto1));
      Console.WriteLine(((IAFIP)av2).CalcularImpuesto() + " ");
      Console.WriteLine("el impuesto para el avion es de : ");
      av1.MostrarPrecio();
      Console.WriteLine("el impuesto para el auto es de : ");
      auto1.MostrarPrecio();
      Console.ReadKey();



    }
  }
}
