using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Televisores;
namespace ConsolaEvento
{
  class Program
  {
    public static void pruebaEvento()
    { Console.WriteLine("se inserto a la base de datos"); }

    public void pruevaEvento2()
    {
      Console.WriteLine("segundo metodo del delegado ");
    }
    public void eventoTv(Televisor a , TvEventsArgs tv)
    {
      Console.WriteLine("codigo :" + a.id + " marca :" + a.marca + " precio :" + a.precio + " pulgadas :" + a.pulgada + " pais :" + a.pais);
      Console.WriteLine(tv.fecha);
    }
    static void Main(string[] args)
    {
      Televisor tele3 = new Televisor(252, "sktelecom", 82000, 75, "korea");
      // le agrego el metodo a mievento
      Program a = new Program(); 
      tele3.miEvento += new miDelegado(pruebaEvento);
      tele3.miEvento += new miDelegado(a.pruevaEvento2);
      tele3.EventoTv += new delegadoTv(a.eventoTv);
      
      tele3.instertar();


      Console.ReadKey();
    }
  }
}
