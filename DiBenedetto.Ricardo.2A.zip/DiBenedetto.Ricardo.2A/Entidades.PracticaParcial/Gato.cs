﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.PracticaParcial
{
    public class Gato : Mascota
    {
        public Gato(string nombre , string raza) : base ( nombre , raza ) 
        {

        }

        protected override string ficha()
        {
            return base.datosCompletos();
        }
        public override string ToString()
        {
            return this.ficha();
        }
        public static bool operator ==(Gato g1, Gato g2)
        {
            bool flag = false;
            if (string.Compare(g1.datosCompletos(), g2.datosCompletos()) == 0 )
            {
                flag = true;
            }
            return flag;
        }
        public static bool operator !=(Gato g1, Gato g2)
        {
            return !(g1 == g2);
        }


    }
}
