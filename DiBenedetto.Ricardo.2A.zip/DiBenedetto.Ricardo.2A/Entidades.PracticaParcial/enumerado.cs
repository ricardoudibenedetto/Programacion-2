﻿public enum TipoManada
{
    unica,
    mixta
}