﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.PracticaParcial
{
    public abstract class Mascota
    {
        string _nombre;
        string _raza;

        public string Nombre { get { return this._nombre; } }
        public string Raza { get { return this._raza; } }

        public Mascota (string nom , string raza)
        {
            this._nombre = nom;
            this._raza = raza;
        }

        protected abstract string ficha();
        protected virtual string datosCompletos()
        {
            string retorno = string.Format("{0}  {1}", _nombre, _raza);
            return retorno;
        }
    }
}
