﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.PracticaParcial
{
   public  class Perro : Mascota
    {
        int _edad;
        bool _esAlfa;

        public int Edad { get { return _edad; } set { this._edad = value; } }
        public bool EsAlfa { get { return this._esAlfa; } set { this._esAlfa = value; } }

        public Perro(string nombre, string raza) : this(0, false, nombre, raza)
        {

        }
        public Perro(int edad, bool alfa, string nombre, string raza) : base(nombre, raza)
        {
            this._edad = edad;
            this._esAlfa = alfa;

        }

        protected override string ficha()
        {
            string aux;
            if (this.EsAlfa == true)
            {
                aux = string.Format("{0}, es alfa de la manada , edad {1}", base.datosCompletos(), this._edad);
            }
            else
            {
                aux = string.Format("{0}, edad {1}", base.datosCompletos(), this._edad);
            }
            return aux;
        }

        public static bool operator ==(Perro p1, Perro p2)
        {
            bool flag = false;
            if (string.Compare(p1.datosCompletos(), p2.datosCompletos()) == 0 && p1._edad == p2._edad)
            {
                flag = true;
            }
            return flag;
        }
        public static bool operator !=(Perro p1, Perro p2)
        {
            return !(p1 == p2);
        }

        public override string ToString()
        {
            return this.ficha();
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }
        public static explicit operator int(Perro p1)
        {
            return p1._edad;
        }

    }
}
