﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.PracticaParcial;

namespace Entidades.PracticaParcial
{
   public  class Grupo
    {
        private List<Mascota> _mascotas;
        string _nombre;
        static TipoManada _tipo;

        public TipoManada Tipo { set { _tipo = value; } }

        static Grupo()
        {
            _tipo= TipoManada.unica;
        }
        private Grupo()
        {
            this._mascotas = new List<Mascota>();
        }
        public Grupo(string nombre): this()
        {
            _nombre = nombre;
        }
        public Grupo ( string nombre , TipoManada tipo):this (nombre)
        {
            _tipo = tipo;
        }

        public static bool operator ==(Grupo grup , Mascota mascota)
        {
            bool flag = false; 
            foreach(Mascota item in grup._mascotas)
            {
                if(item == mascota )
                {
                    flag = true;
                }
            }
            return flag;
        }
        public static bool operator !=(Grupo grup, Mascota mascota)
        {
            return !(grup==mascota);
        }

        public static Grupo operator +(Grupo grup, Mascota mascota)
        {
            foreach(Mascota item in grup._mascotas)
            {
                if(item == mascota )
                {
                    return grup;
                }

               
            }
            grup._mascotas.Add(mascota);
            return grup;
        }
        public static Grupo operator -(Grupo grup, Mascota mast)
        {
            foreach (Mascota item in grup._mascotas)
            {
                if (item == mast)
                {
                    grup._mascotas.Remove(mast);
                    break;
                }
            }

            return grup;
        }

        public static implicit operator string(Grupo E)
        {
            
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("**"+E._nombre+_tipo+"**");
            foreach(Mascota mascota in E._mascotas)
            {
                sb.AppendLine(mascota.ToString());
            }
            return sb.ToString();
        }
    }
}
