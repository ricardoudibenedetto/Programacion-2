using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ejercicioClase_04;
namespace ejercicioClase_04
{
  class Program
  {
    static void Main(string[] args)
    {
      Cosa persona = new Cosa();
      persona.EstablelcerValor("mi vieja mula ya no es lo q era ");
     
      Console.WriteLine(Cosa.Mostrar(persona));
      Console.ReadKey();

    }
  }
}
