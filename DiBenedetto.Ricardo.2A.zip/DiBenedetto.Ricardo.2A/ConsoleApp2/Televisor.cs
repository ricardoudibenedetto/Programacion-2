using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace ConsoleApp2
{
  public class Televisor
  {
    public int id;
    public string marca;
    public double precio;
    public int pulgada;
    public string pais;


    public Televisor(int Id , string Marca , double Precio , int Pulgada , string Pais )
    {
      this.id = Id;
      this.marca = Marca;
      this.precio = Precio;
      this.pulgada = Pulgada;
      this.pais = Pais;
    }
    public bool instertar()
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
       
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "Insert into televisores values(" + this.id + ", '"+ this.marca +"',"+ this.precio + "," + this.pulgada+",'"+this.pais +"')" ;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception)
      {

        flag = false;
      }
      return flag;
    }
    public Televisor() { }
  }
}
