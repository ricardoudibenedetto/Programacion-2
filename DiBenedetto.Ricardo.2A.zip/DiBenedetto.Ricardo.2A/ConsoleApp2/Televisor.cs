using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace ConsoleApp2
{
  public class Televisor
  {
    public int id;
    public string marca;
    public double precio;
    public int pulgada;
    public string pais;


    public Televisor(int Id , string Marca , double Precio , int Pulgada , string Pais )
    {
      this.id = Id;
      this.marca = Marca;
      this.precio = Precio;
      this.pulgada = Pulgada;
      this.pais = Pais;
    }

    public static bool modificar(Televisor t1)
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "update televisores set marca = '" + t1.marca + "',precio =" + t1.precio + ", pulgadas =" + t1.pulgada + ",  pais =' " + t1.pais + "' where codigo ="+t1.id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception)
      {

        flag = false;
      }
      return flag;
    }
    public static bool borrar(Televisor t1)
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "delete televisores where codigo = "+t1.id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception)
      {

        flag = false;
      }
      return flag;
    }
    public bool instertar()
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion); 
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "Insert into televisores values(" + this.id + ", '"+ this.marca +"',"+ this.precio + "," + this.pulgada+",'"+this.pais +"')" ;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception)
      {

        flag = false;
      }
      return flag;
    }

    public static List<Televisor> TraerTodos()
    {
      List<Televisor> televisores = new List<Televisor>();
      try
      {
        SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
        //abre 

        //objeto para asignar valores 
        SqlCommand comando = new SqlCommand();
        comando.CommandText = "select * from televisores";
        comando.CommandType = System.Data.CommandType.Text;
        comando.Connection = conexion;
       
        //se abre la conexion
        conexion.Open();
        //lee y avanza y elimina de la conexion
        SqlDataReader lector = comando.ExecuteReader();
        while (lector.Read())
        {
         // Console.WriteLine(lector[0] + " " + lector[1] + " " + lector[2] + " " + lector[3] + " " + lector[4]);
          televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)));
        }
        conexion.Close();

      }
      catch (Exception)
      {

        return null;
      }
     
    
      return televisores;
    }

  //  public static Televisor traerUno(int id)
  //  {
  //    Televisor t1 = new Televisor();
  //    try
  //    {

        
  //      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
  //      //abre 

  //      //objeto para asignar valores 
  //      SqlCommand comando = new SqlCommand();
  //      comando.CommandText = "select * from televisores where codigo = "+id;
  //      comando.CommandType = System.Data.CommandType.Text;
  //      comando.Connection = conexion;

  //      //se abre la conexion
  //      conexion.Open();
  //      //lee y avanza y elimina de la conexion
  //      SqlDataReader lector = comando.ExecuteReader();
          
  //      while (lector.Read())
  //      {
         // Console.WriteLine(lector[0] + " " + lector[1] + " " + lector[2] + " " + lector[3] + " " + lector[4]);
        //  televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)));
        //}
  //      conexion.Close();
  //    }
  //    catch (Exception)
  //    {

  //      throw;
  //    }
  //  }
  //  public Televisor() { }
}
}
