using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace ConsoleApp2
{
  class Program
  {
    static void Main(string[] args)
    {
      //objeto para establecer conexion
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
      //abre 
      
      //objeto para asignar valores 
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "select * from televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;
      List<Televisor> televisores = new List<Televisor>();
      //se abre la conexion
      conexion.Open();
      //lee y avanza y elimina de la conexion
      SqlDataReader lector = comando.ExecuteReader();
      while(lector.Read())
      {
        Console.WriteLine(lector[0]+" "+ lector[1] +" "+lector[2] +" " +lector[3]+ " " + lector[4] );
        televisores.Add(new Televisor(lector.GetInt32(0), lector.GetString(1), lector.GetDouble(2), lector.GetInt32(3), lector.GetString(4)));
      }
      conexion.Close();

      XmlSerializer serializer = new XmlSerializer(typeof(List<Televisor>));
      XmlTextWriter escribir = new XmlTextWriter("televisores.xml",Encoding.UTF8);
      XmlTextReader leer = new XmlTextReader("televisores.xml");
      //genera un archivo xml en carpeta con la lista serializada

      serializer.Serialize(escribir, televisores);
      escribir.Close();
      //deserealiza el xml y lo trae a memoria , usando el leer ya configurado con el path
      List<Televisor> l = (List<Televisor>)serializer.Deserialize(leer);
      Televisor tele3 = new Televisor(144, "algunamarca", 82000, 75, "korea");
      conexion.Open();
      //if (!tele3.instertar())
      //{
      //  Console.WriteLine("no se pudo agregar");
      //}

      if(!Televisor.borrar(tele3))
      {
        Console.WriteLine("no se puedo modificar ");
      }
      lector = comando.ExecuteReader();
      DataTable table = new DataTable("televisores");
      DataTable table2 = new DataTable();

      table.Load(lector);

      table.WriteXmlSchema("televisores_esquema.xml");
      table.WriteXml("televisores_dt.xml");

      table2.ReadXmlSchema("televisores_esquema.xml");
      table2.ReadXml("televisores_dt.xml");
      List<Televisor> nuevaLista = Televisor.TraerTodos();

      foreach (Televisor item in nuevaLista)
      {
        Console.WriteLine(item.id + " " + item.marca + " " + item.precio + " " + item.pulgada + " " + item.pais);
      }
      Console.ReadKey();
    }
  }
}
