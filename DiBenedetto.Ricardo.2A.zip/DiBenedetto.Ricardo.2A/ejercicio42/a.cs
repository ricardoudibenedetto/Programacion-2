using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio42
{
  class a
  {
    public static Exception lanzarExepcion()
    {
      throw new DivideByZeroException();
    }
  }
}
