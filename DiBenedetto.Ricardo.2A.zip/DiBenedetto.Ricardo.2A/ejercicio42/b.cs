using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio42
{
  class b : Exception
  {
    public b() : base()
    {
      try
      {
        a.lanzarExepcion();
      }
      catch (DivideByZeroException e)
      {
        throw e.InnerException;
        
      }
    }

  

  }
}
