using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio42
{
  class UnaException : Exception
  {
    public static Exception lanzarExepcion()
    {
       throw new DivideByZeroException();
    }



    public UnaException() : base()
    {
      try
      {
        UnaException.lanzarExepcion();
      }
      catch (DivideByZeroException e)
      {
        UnaException nueva = new UnaException(e);
      }
    }


    public UnaException(Exception e)
    {
      Exception UnaPropia = new Exception();
      UnaPropia = e.InnerException;
      throw UnaPropia;
    }


   
  }
}
