using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfDelegados
{
  public partial class frmTestDelegados : Form
  {
    public frmTestDelegados()
    {
      InitializeComponent();
    }

    
    
    private void frmTestDelegados_Load(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      string s = this.textBox1.Text;
      ((Form1)this.Owner).midel(s);
    }
  }
}
