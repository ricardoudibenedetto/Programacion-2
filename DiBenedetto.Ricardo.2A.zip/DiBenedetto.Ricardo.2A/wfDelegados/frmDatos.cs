using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfDelegados
{
  public partial class frmDatos : Form
  {
    public frmDatos()
    {
      InitializeComponent();
    }

    private void frmDatos_Load(object sender, EventArgs e)
    {

    }

    public void actualizarNombre(string s)
    {
      this.label1.Text = s;
    }
  }
}
