using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfDelegados
{
  public partial class Form1 : Form
  {
    public ActualizarNombrePorDelegado midel;
    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      IsMdiContainer = true;
    }

    private void testDelegadosToolStripMenuItem_Click(object sender, EventArgs e)
    {
      frmTestDelegados form = new frmTestDelegados();
    
  
      form.Show(this);
    }
     
    private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
    {
      frmDatos form = new frmDatos();

      form.Show(this);
      this.midel += new ActualizarNombrePorDelegado(form.actualizarNombre);
    }
  }
}
