using System;

namespace Entidades.AdministradorArchivos
{
    public static class Class1
    {

    }
}
