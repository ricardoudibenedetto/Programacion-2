using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace Entidades.AdministradorArchivos
{
    public static class AdministradorArchivos
    {
    public static bool Escribir(string path, string b)
    {
      bool flag = false;
      try
      {
        StreamWriter sw;
        using (sw = new StreamWriter(path, true))
        {
          sw.WriteLine(b);
        }
        flag = true;
      }
      catch (Exception)
      {
        flag = false;
      }
      return flag;
    }
    
    public static bool Leer(string path, out string b)
    {
      bool flag = false;
      b = "";
      try
      {

        StreamReader sw;
        using (sw = new StreamReader(path, true))
        {
          b = sw.ReadToEnd();
        }
        flag = true;
      }
      catch (Exception)
      {
        flag = false;
      }
      return flag;
    }
    }
}
