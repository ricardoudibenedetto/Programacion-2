using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio02
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "ejercicio02";
      double num;
      double numCuadrado;
      double numCubo;
      Console.WriteLine("ingrese un numero positivo");
      num = double.Parse(Console.ReadLine());
      while(num<0)
      {
        Console.WriteLine("ERROR, EL NUMERO DEBE SER POSITIVO");
        Console.WriteLine("ingrese un numero positivo");
        num = double.Parse(Console.ReadLine());
      }
      numCubo = Math.Pow(num, 3);
      numCuadrado = Math.Pow(num, 2);
      Console.WriteLine("el numero elevado al cuadrado es :{0}\nel numero elevado al cubo es :{1}", numCuadrado, numCubo);
      Console.ReadKey();
    }
  }
}
