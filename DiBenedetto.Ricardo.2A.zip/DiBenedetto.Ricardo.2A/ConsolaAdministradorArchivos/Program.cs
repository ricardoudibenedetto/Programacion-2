using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.AdministradorArchivos;
namespace ConsolaAdministradorArchivos
{
  class Program
  {
    static void Main(string[] args)
    {
      string a;
      string b = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\prueba2.txt";
      string c = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\prueba2.txt";
      string d = AppDomain.CurrentDomain.BaseDirectory + @"\prubea2.txt";
      
       
      // MIS DOCUMENTOS
      if ( AdministradorArchivos.Escribir(b, "mensaje de prueba"))
        {
        Console.WriteLine("se pudo guardar con exito ");
      }
     else
      {
        Console.WriteLine("No se pudo guardar");
      }
      if(AdministradorArchivos.Leer(b,out a))
        {
        Console.WriteLine("se pudo leer con exito");
      }else
      {
        Console.WriteLine("no se pudo leer ");
      }


      //MI ESCRITORIO
      if (AdministradorArchivos.Escribir(c, a))
      {
        Console.WriteLine("se pudo guardar con exito ");
      }
      else
      {
        Console.WriteLine("No se pudo guardar");
      }
      if (AdministradorArchivos.Leer(b, out a))
      {
        Console.WriteLine("se pudo leer con exito");
      }
      else
      {
        Console.WriteLine("no se pudo leer ");
      }


      //Mis IMAGENES
      if (AdministradorArchivos.Escribir(d, a))
      {
        Console.WriteLine("se pudo guardar con exito ");
      }
      else
      {
        Console.WriteLine("No se pudo guardar");
      }
      if (AdministradorArchivos.Leer(b, out a))
      {
        Console.WriteLine("se pudo leer con exito");
      }
      else
      {
        Console.WriteLine("no se pudo leer ");
      }
      Console.WriteLine(a);
      Console.ReadKey();

    }
  }
}
