﻿using System;

namespace Entidades.clase10.parte3
{
    public class Class1
    {
    }
}
