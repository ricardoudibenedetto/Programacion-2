using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace Entidades.clase10.parte3
{
    public class Deposito<T>
  {
    #region atributos
    int _capacidadMaxima;
    List<T> deposito;
    #endregion
    #region metodo
    public Deposito(int capadidad)
    {
      this._capacidadMaxima = capadidad;
      this.deposito = new List<T>(capadidad);
    }

    public static bool operator +(Deposito<T> d, T a1)
    {
      bool flag = false;
      if (d.deposito.Count < d._capacidadMaxima)
      {
        d.deposito.Add(a1);
        flag = true;
      }
      return flag;
    }


    private int GetIndice(T a)
    {
      int flag = -1;
      int contadore = 0;
      foreach (T item in this.deposito)
      {
        if (item.Equals(a))
        {
          flag = contadore;
          break;
        }

        contadore++;
      }
      return flag;
    }

    public static bool operator -(Deposito<T> d, T a1)
    {
      bool flag = false;
      int indice;
      indice = d.GetIndice(a1);
      if (indice != -1)
      {
        d.deposito.RemoveAt(indice);
        flag = true;
      }
      return flag;
    }

    public bool Agregar(T a)
    {

      return this + a;

    }

    public bool Remover(T a)
    {

      return this - a;

    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("capacidad : " + this._capacidadMaxima);
      foreach (T item in this.deposito)
      {
        sb.AppendLine(item.ToString());
      }
      return sb.ToString();
    }

    public bool guardar(string path)
    {
      bool flag = false;
      try
      {
        StreamWriter sw;
        using (sw = new StreamWriter(path, true))
        {
          sw.WriteLine(this.ToString());
        }
        flag = true;
      }
      catch (Exception)
      {
        flag = false;
      }
      return flag;

    }

    public bool recuperar(string path)
    {
      bool flag = false;
      try
      {

        StreamReader sw;
        using (sw = new StreamReader(path, true))
        {
          Console.WriteLine(sw.ReadToEnd());
        }
        flag = true;
      }
      catch (Exception)
      {
        flag = false;
      }
      return flag;

    }
    #endregion
  }
}
