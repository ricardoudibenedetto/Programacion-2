using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase07

{
  class Tempera
  {
    #region ATRIBUTOS
    private sbyte _cantidad;
    private ConsoleColor _color;
    private string _marca;
    #endregion
    #region CONSTRUCTOR
    public Tempera(sbyte cant, ConsoleColor color, string marca)
    {
      _cantidad = cant;
      _color = color;
      _marca = marca;
    }
    #endregion
    #region METODOS   
    private string mostrar()
    {
      string returnAux;
      returnAux = this._marca + " " + this._color + " " + this._cantidad;  
      return returnAux;
    }
    #endregion
    #region SOBRECARGA
    public static implicit operator string(Tempera t1)
    {
      return t1.mostrar();
    }
    public static explicit operator sbyte(Tempera t1)
    {
      return t1._cantidad;
    }
    public static bool operator ==(Tempera t1, Tempera t2)
    {
      bool retorno = false;

      if (t1._marca == t2._marca && t2._color == t1._color)
      {
        retorno = true;
      }
      return retorno;
    }
    public static bool operator !=(Tempera t1, Tempera t2)
    {
      return !(t1 == t2);
    }

    public static Tempera operator +(Tempera t1, sbyte cant)
    {
      t1._cantidad += cant;
      return t1;
    }
    public static Tempera operator +(Tempera t1, Tempera t2)
    {
      Tempera t3 = new Tempera(t1._cantidad, t1._color, t1._marca);
      if(t1==t2)
      {
        t3 += t2._cantidad; 
      }
      return t3;
    }
    #endregion
  }
}
