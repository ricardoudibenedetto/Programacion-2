using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.clase07
{
  public class PaletaColeccion
    {
    //private Tempera[] _colores;
    List<Tempera> _colores = new List<Tempera>();
    private int _cantMaximaElementos;
    #region CONSTRUCTOR
    private PaletaColeccion() : this(5)
    {

    }
    private PaletaColeccion(int cant)
    {
      this._cantMaximaElementos = cant;
      //this._colores = new Tempera[_cantMaximaElementos];
      //this._colores = _colores.Add(new Tempera(_cantMaximaElementos));
    }
    #endregion
    #region METODO
    public int cantidadTemp {
      get { return this._colores.Count; }
    }
    private string mostrar()
    {
      string returnAux;
      returnAux = _cantMaximaElementos + " ";
      foreach(Tempera items in this._colores)
      {
        if(!object.Equals(items,null))
        returnAux += "\r\n" + items;
      }
      return returnAux;
    }

    public static explicit operator string(PaletaColeccion p1)
    {
      return p1.mostrar();
    }

    public static implicit operator PaletaColeccion(int cant)
    {

      return new PaletaColeccion(cant);
    }
    private  int obtenerIndice()
    {
      int returnAux = -1;
      int i = 0;
      foreach (Tempera items in this._colores)
      {
        
        if (object.Equals(items, null))
        {
          returnAux = i;
          break;
        }
        i++;
      }
      return returnAux;
    }
    private int obtenerIndice(Tempera t1)
    {
      int returnAux = -1;
      int i = 0;
      foreach (Tempera items in this._colores)
      {

        if (!object.Equals(items, null))
        {
          if(t1 == items)
          returnAux = i;
          break;
        }
        i++;
      }
      return returnAux;

    }
    #endregion
    #region SOBRECARGA
    public static Tempera[] operator +(PaletaColeccion p1, int indice )
    {

      int i = indice >= p1._colores.Count ? ++indice : --indice;
      Tempera[] aux = new Tempera[i];
      p1._colores.CopyTo(aux, 0);
      return aux;
    }
    public static bool operator ==(PaletaColeccion p1, Tempera t2 )
    {
      bool retorno = false;
      foreach(Tempera items in p1._colores)
      {
        if(!object.Equals(items,null))
        {
          if (items == t2)
          {
            retorno = true;
            break;
          }
        }
      }
      return retorno;
    }
    public static bool operator !=(PaletaColeccion p1, Tempera t2)
    {
      
      return !(p1==t2);
    }


    //MASSS
    public static PaletaColeccion operator +(PaletaColeccion p1, Tempera t2)
    {
      int indice;
      if (p1._cantMaximaElementos > p1._colores.Count)
      {
        if (p1 == t2)
        {
          indice = p1.obtenerIndice(t2);
          p1._colores[indice] += t2;
        }
        else
        {
          //indice = p1.obtenerIndice();
          //if (indice > -1)
          //  p1._colores[indice] = t2;
          p1._colores.Add(t2);
        }

      }
      return p1;
    }

    public static PaletaColeccion operator -(PaletaColeccion p1, Tempera t2)
    {
      int indice;
      sbyte variable1;
      sbyte variable2;
      if (p1 == t2)
      {
        indice = p1.obtenerIndice(t2);
        variable1 = (sbyte)p1._colores[indice];
        variable2 = (sbyte)t2;


        if (variable1-variable2 <= 0)
        {
          p1._colores[indice] = null;
        }
        else
        {
          p1._colores[indice] += (sbyte)(variable2 * (-1));
        }

      }
     
      return p1;
    }
    #endregion

    #region IDEXADOR
    public Tempera this[int indice]
    {

      get
      {
        if (indice >= this._colores.Count || indice < 0)
        {
          return null;
        }
        else
        {
          return this._colores[indice];

        }
    }
      set
      {
        if(indice >=0 && indice == this._colores.Count)
        {
          this._colores[indice] = value;

        }
        else
        {
          if(indice == this._colores.Count)
          {
            //  this._colores = this + indice;
            //  this[indice] = value;
            this._colores.Add(value);

          }
        }
      }
    }
    #endregion
  }

}
