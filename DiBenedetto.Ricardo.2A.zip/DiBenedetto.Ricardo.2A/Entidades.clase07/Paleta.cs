using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase07
{
    public class Paleta
    {
    private Tempera[] _colores;
    private int _cantMaximaElementos;
    #region CONSTRUCTOR
    private Paleta():this(5)
    {

    }
    private Paleta(int cant)
    {
      this._cantMaximaElementos = cant;
      this._colores = new Tempera[_cantMaximaElementos];
    }
    #endregion
    #region METODO
    private string mostrar()
    {
      string returnAux;
      returnAux = _cantMaximaElementos + " ";
      foreach(Tempera items in this._colores)
      {
        returnAux += "\n" + items;
      }
      return returnAux;
    }

    public static explicit operator string(Paleta p1)
    {
      return p1.mostrar();
    }

    public static implicit operator Paleta(int cant)
    {
    
      return new Paleta(cant);
    }
    private  int obtenerIndice()
    {
      int returnAux = -1;
      int i = 0;
      foreach (Tempera items in this._colores)
      {
        
        if (object.Equals(items, null))
        {
          returnAux = i;
          break;
        }
        i++;
      }
      return returnAux;
    }
    private int obtenerIndice(Tempera t1)
    {
      int returnAux = -1;
      int i = 0;
      foreach (Tempera items in this._colores)
      {

        if (!object.Equals(items, null))
        {
          if(t1 == items)
          returnAux = i;
          break;
        }
        i++;
      }
      return returnAux;

    }
    #endregion
    #region SOBRECARGA
    public static bool operator ==(Paleta p1, Tempera t2 )
    {
      bool retorno = false;
      foreach(Tempera items in p1._colores)
      {
        if(!object.Equals(items,null))
        {
          if (items == t2)
          {
            retorno = true;
            break;
          }
        }
      }
      return retorno;
    }
    public static bool operator !=(Paleta p1, Tempera t2)
    {
      
      return !(p1==t2);
    }
    public static Paleta operator +(Paleta p1, Tempera t2)
    {
      int indice;
      if(p1 == t2)
      {
        indice = p1.obtenerIndice(t2);
        p1._colores[indice] += t2;
      }
      else
      {
        indice = p1.obtenerIndice();
        if(indice>-1)
        p1._colores[indice] = t2;
      }
      return p1;
    }

    public static Paleta operator -(Paleta p1, Tempera t2)
    {
      int indice;
      sbyte variable1;
      sbyte variable2;
      if (p1 == t2)
      {
        indice = p1.obtenerIndice(t2);
        variable1 = (sbyte)p1._colores[indice];
        variable2 = (sbyte)t2;


        if (variable1-variable2 <= 0)
        {
          p1._colores[indice] = null;
        }
        else
        {
          p1._colores[indice] += (sbyte)(variable2 * (-1));
        }

      }
     
      return p1;
    }
    #endregion
  }
}
