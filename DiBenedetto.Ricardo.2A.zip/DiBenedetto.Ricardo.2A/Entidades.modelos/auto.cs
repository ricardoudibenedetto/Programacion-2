using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
    class auto : vehiculo
    {
    protected int _cantidadAsientos;

    public auto(string patente , Emarca marca , int cantAsientos , byte cantRuedas) : base(patente , cantRuedas , marca)
    {
      this._cantidadAsientos = cantAsientos;
    }
    public auto(string patente ,Emarca marca , int cantAsientos ) : this (patente , marca, cantAsientos, 4)
    {

    }

    protected override string _mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base._mostrar());
      sb.AppendLine("marca : " + this._cantidadAsientos);
      return sb.ToString();
    }

    public override string ToString()
    {
      return this._mostrar();
    }

  }
}
