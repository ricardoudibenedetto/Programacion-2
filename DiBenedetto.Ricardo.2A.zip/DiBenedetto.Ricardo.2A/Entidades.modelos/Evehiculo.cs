public enum Evehiculo
{
  auto,
  moto,
  camion
}
