using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
    class moto : vehiculo
    {
    
    protected float _cilindrada;

    public moto(string patente , Emarca marca , byte cantRuedas , float cilindrada  ) : base (patente, cantRuedas , marca)
    {
      this._cilindrada = cilindrada;
    }

    protected override string _mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base._mostrar());
      sb.AppendLine("marca : " + this._cilindrada);
      return sb.ToString();
    }

    public override string ToString()
    {
      return this._mostrar();
    }
  }
}
