using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
    class vehiculo
    {
    protected string _patente;
    protected byte _cantRuedas;
    protected Emarca _marca;


    public string getPatente { get { return this._patente; } }
    public byte getCantRuedas { get {return this._cantRuedas  ; } set { this._cantRuedas = value  ; } }
    public Emarca getMarca { get {return this._marca; } }

    protected virtual string _mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("marca : " + this._marca);
      sb.AppendLine("patente : " + this._patente);
      sb.AppendLine("cantidad de ruedas : " + this._cantRuedas);
      return sb.ToString();
    }

    public vehiculo(string patente , byte cantRued , Emarca marca)
    {
      this._patente = patente;
      this._cantRuedas = cantRued;
      this._marca = marca;
    }

    public override string ToString()
    {
      return this._mostrar();
    }

    public static bool operator ==(vehiculo v1 , vehiculo v2)
    {
      bool returnAux= false;
      if(v1._patente==v2._patente && v2._marca == v1._marca)
      {
        returnAux = true;
      }
      return returnAux;
    }
    public static bool operator !=(vehiculo v1, vehiculo v2)
    {
      return !(v1 == v2);
    }

  }
}
