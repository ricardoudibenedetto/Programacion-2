using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
  public class lavadero
  {
    private List<vehiculo> _vehiculos;
    static float _precioAuto;
    static float _precioCamion;
    static float _precioMoto;
    string razonSocial;

    static lavadero()
    {
      Random rm = new Random();
      do
      {
        _precioAuto = rm.Next(150, 566);
        _precioCamion = rm.Next(150, 566);
        _precioMoto = rm.Next(150, 566);
      } while (_precioAuto == _precioCamion || _precioAuto == _precioMoto || _precioCamion == _precioMoto);
    }

    public lavadero()
    {
      this._vehiculos = new List<vehiculo>();
    }

    public lavadero(string razonsocial) : this()
    {
      this.razonSocial = razonsocial;
    }
    public string lavaderoToString
    {
      get
      {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("precios : moto: " + _precioMoto + " auto: " + _precioAuto + " camion: " + _precioCamion);
        sb.AppendLine("razon social :" + razonSocial);
        foreach (vehiculo item in this._vehiculos)
        {
          sb.AppendLine(item.ToString());
        }
        return sb.ToString();
      }
    }
    public List<vehiculo> Vehiculos { get { return this._vehiculos; } }

    public double mostrarTotalFacturado()
    {
      double valorTotal = this.mostrarTotalFacturado(Evehiculo.auto)+ this.mostrarTotalFacturado(Evehiculo.moto)+ this.mostrarTotalFacturado(Evehiculo.camion);
            //foreach (vehiculo vel in this._vehiculos)
            //{
            //    if (vel is auto)
            //    {
            //        valorTotal += _precioAuto;
            //    }
            //    else
            //    {
            //        if (vel is moto)
            //        {
            //            valorTotal += _precioMoto;
            //        }
            //        else
            //        {
            //            valorTotal += _precioCamion;
            //        }
            //    }

            //}
            return valorTotal;
    }
    public double mostrarTotalFacturado(Evehiculo eve)
    {
      double valtotal = 0;
      foreach (vehiculo item in this._vehiculos)
      {
        switch (eve)
        {
          case Evehiculo.auto:
            if (item is auto)
            {
              valtotal += _precioAuto;
            }
            break;
          case Evehiculo.moto:
            if (item is moto)
            {
              valtotal += _precioAuto;
            }
            break;
          case Evehiculo.camion:
            if (item is camion)
            {
              valtotal += _precioAuto;
            }
            break;
          default:
            break;
        }
      }
      return valtotal;
    }
    public static int operator ==(lavadero lava, vehiculo vehi)
    {
      int flag = -1;
      //foreach (vehiculo item in lava._vehiculos)
      //{
      for(int i = 0; i < lava._vehiculos.Count; i++)
        if (vehi == lava._vehiculos[i])
          flag = i;
      //}
      return flag;
    }
    public static int operator !=(lavadero lava, vehiculo vehi)
    {
      return -1;
    }

    public static lavadero operator +(lavadero lav , vehiculo vehi)
        {
           foreach(vehiculo item in lav._vehiculos)
            {
                if (item == vehi)
                    return lav;
            }
            lav._vehiculos.Add(vehi);
            return lav;
        }

    public static lavadero operator -(lavadero lav, vehiculo vehi)
        {
            foreach (vehiculo item in lav._vehiculos)
            {
                if (item == vehi)
                    lav._vehiculos.Remove(vehi);
                    return lav;
            }
            
            return lav;
        }

        public static int ordenarPorPatente(vehiculo v1, vehiculo v2)
        {
            int valor = 0;
            valor = string.Compare(v1.getPatente,v2.getPatente);
            return valor;
        }
        public static int ordenarPorMarca(vehiculo v1 , vehiculo v2)
        {
            int valor = 0;
            if (v1.getMarca == v2.getMarca)
            {
                valor = 0;
            }
            else
            {
               
                if (v1.getMarca > v2.getMarca)
                {
                    valor = 1;
                }
                else
                {
                    valor = -1;
                }
            }

            //int valor = 0;
            //string marca1, marca2;
            //marca1 = Enum.GetName(typeof(EMarca), obj1.Marca);
            //marca2 = Enum.GetName(typeof(EMarca), obj2.Marca);
            //valor = string.Compare(marca1, marca2);
            //return valor;
            return valor;
        }
  }
}
