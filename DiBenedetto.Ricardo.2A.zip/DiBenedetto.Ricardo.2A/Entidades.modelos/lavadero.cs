using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
  class lavadero
  {
    private List<vehiculo> _vehiculos;
    static float _precioAuto;
    static float _precioCamion;
    static float _precioMoto;
    string razonSocial;

    static lavadero()
    {
      Random rm = new Random();
      do
      {
        _precioAuto = rm.Next(150, 566);
        _precioCamion = rm.Next(150, 566);
        _precioMoto = rm.Next(150, 566);
      } while (_precioAuto == _precioCamion || _precioAuto == _precioMoto || _precioCamion == _precioMoto);
    }

    public lavadero()
    {
      this._vehiculos = new List<vehiculo>();
    }

    public lavadero(string razonsocial) : this()
    {
      this.razonSocial = razonsocial;
    }
    public string lavaderoToString
    {
      get
      {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("precios : moto: " + _precioMoto + " auto: " + _precioAuto + " camion: " + _precioCamion);
        sb.AppendLine("razon social :" + razonSocial);
        foreach (vehiculo item in this._vehiculos)
        {
          sb.AppendLine(item.ToString());
        }
        return sb.ToString();
      }
    }
    public List<vehiculo> Vehiculos { get { return this._vehiculos; } }

    public double mostrarTotalFacturado()
    {
      double valorTotal = 0;
      foreach (vehiculo vel in this._vehiculos)
      {
        if (vel is auto)
        {
          valorTotal += _precioAuto;
        }
        else
        {
          if (vel is moto)
          {
            valorTotal += _precioMoto;
          }
          else
          {
            valorTotal += _precioCamion;
          }
        }

      }
      return valorTotal;
    }
    public double mostrarTotalFacturado(Evehiculo eve)
    {
      double valtotal = 0;
      foreach (vehiculo item in this._vehiculos)
      {
        switch (eve)
        {
          case Evehiculo.auto:
            if (item is auto)
            {
              valtotal += _precioAuto;
            }
            break;
          case Evehiculo.moto:
            if (item is moto)
            {
              valtotal += _precioAuto;
            }
            break;
          case Evehiculo.camion:
            if (item is camion)
            {
              valtotal += _precioAuto;
            }
            break;
          default:
            break;
        }
      }
      return valtotal;
    }
    public static bool operator ==(lavadero lava, vehiculo vehi)
    {
      bool flag = false;
      foreach (vehiculo item in lava._vehiculos)
      {
        if (item == vehi)
          flag = true;
      }
      return flag;
    }
    public static bool operator !=(lavadero lava, vehiculo vehi)
    {
      return !(lava == vehi);
    }
  }
}
