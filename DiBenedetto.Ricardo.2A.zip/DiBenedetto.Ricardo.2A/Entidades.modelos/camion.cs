using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.modelos
{
    public class camion : vehiculo
    {
    protected  float _tara;

    public camion(string patente, float tara, Emarca marca , byte cantRuedas) : base(patente, 6, marca)
    {
      this._tara = tara;
    }
    public camion ( vehiculo vehiculo , float tara ): this (vehiculo.getPatente , tara , vehiculo.getMarca , vehiculo.getCantRuedas)
    {
     
    }
    protected override string _mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base._mostrar());
      sb.AppendLine("tara : " + this._tara);
      return sb.ToString();
    }

    public override string ToString()
    {
      return this._mostrar();
    }
  }
}
