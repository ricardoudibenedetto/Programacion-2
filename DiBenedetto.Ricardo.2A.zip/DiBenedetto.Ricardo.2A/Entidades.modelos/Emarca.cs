public enum Emarca{
  honda,
    ford,
    zanella,
    scania,
    iveco,
    fiat

}
