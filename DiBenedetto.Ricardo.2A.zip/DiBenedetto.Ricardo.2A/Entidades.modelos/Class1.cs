﻿using System;

namespace Entidades.modelos
{
    public class Class1
    {
    }
}
