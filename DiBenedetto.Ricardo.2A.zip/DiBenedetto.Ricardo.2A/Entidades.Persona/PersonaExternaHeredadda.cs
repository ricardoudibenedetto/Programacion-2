using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;
namespace Entidades.Persona
{
  public class PersonaExternaHeredadda : PersonaExterna
  {

    public string  Nombre { get { return base._nombre; } }
    public string Apellido { get { return base._apellido; } }
    public int Edad { get { return base._edad; } }
    public Entidades.Externa.ESexo Sexo {get { return base._sexo; } }

    
    public PersonaExternaHeredadda(string nombre , string apellido , int edad , Entidades.Externa.ESexo sex):base(nombre, apellido , edad , sex)
    {

    }

    public string ObtenerDatos()
    {
      return "Nombre:" + this.Nombre + "   Apellido:" + this.Apellido + "  Edad:" + this.Edad + "  Sexo:" + this.Sexo;
    }
  }
}
