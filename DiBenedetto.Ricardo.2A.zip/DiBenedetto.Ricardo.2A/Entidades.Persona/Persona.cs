using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Persona
{
  public class Persona
  {
    protected string _nombre;
    protected string _apellido;
    protected int _edad;
    protected ESexo _sexo;


    public Persona(string nom, string ape , int edad , ESexo sex)
    {
      this._nombre = nom;
      this._apellido = ape;
      this._edad = edad;
      this._sexo = sex;
    }

    public string Nombre { get {return this._nombre; } }
    public string Apellido { get {return this._apellido; }  }
    public int Edad { get {return this._edad; }  }
    public ESexo Sexo { get { return this._sexo; } }

    //metodos

    public string ObtenerDatos()
    {
      return "Nombre:" + this.Nombre + "   Apellido:" + this.Apellido + "  Edad:" + this.Edad + "  Sexo:" + this.Sexo;
    }

  }
}
