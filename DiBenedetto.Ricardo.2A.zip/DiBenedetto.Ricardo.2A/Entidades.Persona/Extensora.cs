using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Entidades.Persona
{
  public static class Extensora
  {
    //metodo que muestra datos de la persona , esxtendida a la clase sellada 
    public static string ObtenerDatos(this Entidades.Externa.Sellada.PersonaExternaSellada Persona)
    {
      return "Nombre:" + Persona.Nombre + "   Apellido:" + Persona.Apellido + "  Edad:" + Persona.Edad + "  Sexo:" + Persona.Sexo;
    }


    public static bool EsNulo(this System.Object param)
    {
      if(object.Equals(param , null))
      {
        return true;
      }
      return false;
    }

    public static int CantidadDigitos(this Int32 num)
    {
      string nums;
      nums = num.ToString();
      return nums.Length;
    }

    public static bool TieneLaMismaCantidad(this Int32 num1 , int num2)
    {
      int uno = num1.CantidadDigitos();
      
      if(uno == num2)
      {
        return true;
      }
      return false;
    }

    public static List<Persona> TraerDB(this Entidades.Persona.Persona persona )
    {
      List<Persona> Personas = new List<Persona>();
      try
      {
        SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
        //abre 

        //objeto para asignar valores 
        SqlCommand comando = new SqlCommand();
        comando.CommandText = "select * from Personas";
        comando.CommandType = System.Data.CommandType.Text;
        comando.Connection = conexion;

        //se abre la conexion
        conexion.Open();
        //lee y avanza y elimina de la conexion
        SqlDataReader lector = comando.ExecuteReader();
        while (lector.Read())
        {
          // Console.WriteLine(lector[0] + " " + lector[1] + " " + lector[2] + " " + lector[3] + " " + lector[4]);
          Personas.Add(new Persona(lector.GetString(1), lector.GetString(2), lector.GetInt32(3), (ESexo)lector.GetInt32(4)));
        }
        conexion.Close();

      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
        return null;
      }


      return Personas;

    }


    public static bool AgregarDB(this Entidades.Persona.Persona per)
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "Insert into Personas values( '" + per.Nombre + "', '" + per.Apellido + "'," + per.Edad + ",'" + (int)per.Sexo + "')";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception)
      {

        flag = false;
      }
      return flag;
    }

    public static bool quitarDB(this Persona per, int id )
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "delete Personas where id = " + id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
        flag = false;
      }
      return flag;
    }


    public static bool ModificarDB(this Persona per, int id )
    {
      bool flag = true;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();
      comando.CommandText = "update Personas set nombre ='" + per.Nombre + "',apellido = '" + per.Apellido + "',edad = " + per.Edad + ", sexo = " + (int)per.Sexo + " WHERE id = "+id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
      }
      catch (Exception e)
      {
        Console.WriteLine(e.Message);
        flag = false;
      }
      return flag;

    }
  }
}
