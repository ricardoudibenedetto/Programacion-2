﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.modelos;
namespace practica1p
{
    class Program
    {
        static void Main(string[] args)
        {
            lavadero lv = new lavadero("hola");

            auto auto1 = new auto("123", Emarca.fiat , 4);
            auto auto2 = new auto("aaa", Emarca.ford, 5);
            camion c1 = new camion("bbb",5000,Emarca.iveco, 5);
            moto m1 = new moto("cc",Emarca.honda,2,20);

            lv += auto1;
            lv += c1;
            lv += auto2;
            lv += m1;
          
            
            lv.Vehiculos.Sort(lavadero.ordenarPorPatente);
            
            Console.WriteLine(lv.lavaderoToString);
            Console.WriteLine(lv.mostrarTotalFacturado());
            Console.ReadKey();


        }
    }
}
