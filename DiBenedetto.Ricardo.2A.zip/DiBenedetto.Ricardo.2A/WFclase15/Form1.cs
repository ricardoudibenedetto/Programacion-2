using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFclase15
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    public void MiManejadorclick(object a, EventArgs b)
    {
      MessageBox.Show(((Control)a).Name);
      ((Control)a).Click -= new EventHandler(MiManejadorclick);
    }

    public void ManejadorCentral(object a , EventArgs e )
    {
      
      this.button1.Click -= new EventHandler(MiManejadorclick);
      this.button1.Click -= new EventHandler(ManejadorCentral);
      //this.button1.Click += new EventHandler(MiManejadorclick);
      this.button2.Click += new EventHandler(MiManejadorclick);
      this.textBox1.Click += new EventHandler(MiManejadorclick);



    }

    public void OtroManejadorClick(object a , EventArgs e)
    {
      //quita manejador de evento de boton 2
      //para quitar la sintaxis es sinmilar a la de agregar , -=
      ((Control)a).Click += new EventHandler(MiManejadorclick);
      //this.button2.Click -= new EventHandler(MiManejadorclick);
      //this.button1.Click += new EventHandler(MiManejadorclick);
      //((Control)a).Click -= new EventHandler(MiManejadorclick);
      //this.button2.Click += new EventHandler(MiManejadorclick);
    }

    public void CambiarFondo (object o , EventArgs e)
    {
      //cambiar el fonbdo del boton q recibe el evento

      ((Control)o).BackColor = Color.Cyan; 

    }

    private void Form1_Load(object sender, EventArgs e)
    {
      this.button1.Click += new EventHandler(MiManejadorclick);
      this.button1.Click += new EventHandler(ManejadorCentral);
      //this.button2.Click += new EventHandler(ManejadorCentral);
      //this.textBox1.Click += new EventHandler(ManejadorCentral);
      // //muestra en msj el bt1
      // this.button1.Click += new EventHandler(MiManejadorclick);
      // //muestra bt2
      //this.button2.Click += new EventHandler(MiManejadorclick);
      // //muestra textbox
      //this.textBox1.Click += new EventHandler(MiManejadorclick);
      // //va a ejecutar el evento otromaj}bnejador cuando se haga click en el form
      // this.Click += new EventHandler(OtroManejadorClick);
      // // cambia el color del boton asignado 
      // this.button1.Click += new EventHandler(CambiarFondo);


      //IsMdiContainer = true;

    }

    private void button3_Click(object sender, EventArgs e)
    {
      this.button1.Click -= new EventHandler(MiManejadorclick);
      this.button1.Click -= new EventHandler(CambiarFondo);
      this.button2.Click -= new EventHandler(MiManejadorclick);
      this.textBox1.Click -= new EventHandler(MiManejadorclick);
      this.Click -= new EventHandler(OtroManejadorClick);
    }

    private void button2_Click(object sender, EventArgs e)
    {

    }
  }
}
