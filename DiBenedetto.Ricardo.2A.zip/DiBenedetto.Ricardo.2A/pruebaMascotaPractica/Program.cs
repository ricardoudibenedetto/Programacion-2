﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.PracticaParcial;

namespace pruebaMascotaPractica
{
    class Program
    {
        static void Main(string[] args)
        {
            Grupo lv = new Grupo("mascotas", TipoManada.mixta);

            Gato g1 = new Gato("gatito","melchor");
            Perro p1 = new Perro(5, true, "juancarlo", "pug");
            Perro p2 = new Perro(1, false, "pepe", "pug");
            Perro p3 = new Perro("raul", "booldog");
            lv += g1;
            lv += p1;
            lv += p2;


            Console.WriteLine(lv);
            lv -= g1;

            Console.ReadKey();
            Console.WriteLine(lv);
            Console.ReadKey();
            lv += p3;
            Console.WriteLine(lv);
            Console.ReadKey();


        }
    }
}
