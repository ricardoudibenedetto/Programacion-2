using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.clase07;
namespace testwfclase08
{
  public partial class Frmtempera : Form
  {
    private Tempera _miTempera;

    public Tempera MiTempera {

      get { return this._miTempera; }
    }

    
    //private string _otro;

    //public string Otro
    //{
    //  get { return _otro; }
    //  set { _otro = value; }
    //}


    //public Tempera GetTempera() { return this._miTempera; }

    public Frmtempera()
    {
    
      InitializeComponent();
      foreach (ConsoleColor item in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.comboBox1.Items.Add(item);


      }
      this.comboBox1.SelectedItem = ConsoleColor.Cyan;
      this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void Frmtempera_Load(object sender, EventArgs e)
    {

    }

    private void button1_Click(object sender, EventArgs e)
    {
      this._miTempera = new Tempera(sbyte.Parse(this.textBox1.Text), (ConsoleColor)this.comboBox1.SelectedItem, this.textBox2.Text);
      this.DialogResult = DialogResult.OK;
    }

    private void button2_Click(object sender, EventArgs e)
    {
      this.DialogResult = DialogResult.Cancel;
    }

    public Frmtempera(Tempera t1):this()
    {
      this._miTempera = t1;
      MessageBox.Show("en constructor");
    }
  }
 
}
