﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Cartuchera
{
    class Goma : Utiles
    {
        protected bool _soloLapiz;

        protected override double Precio { get { return base._precio; } set { base._precio = value; } }
        protected override string Marca { get { return base._marca; } set { base._marca = value; } }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.utilesToString());
            sb.AppendLine(this._soloLapiz.ToString());
            
            return sb.ToString();
        }
    }
}
