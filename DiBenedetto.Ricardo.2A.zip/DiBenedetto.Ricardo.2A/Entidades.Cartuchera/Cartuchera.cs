﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Cartuchera
{
    class Cartuchera<T>
    {
        protected string _marca;
        protected byte _capacidad;
        protected List<T> _elementos;
        private Cartuchera ()
        {
            _elementos = new List<T>();
        }
        public Cartuchera(byte capacidad):this()
        {
            this._capacidad = capacidad;
            
        }

        public static implicit operator Cartuchera<T>(byte capacidad)
        {

            return new Cartuchera<T>(capacidad); 
        }

        public void add(T element)
        {
            if(this._elementos.Count < this._capacidad)
            {
                this._elementos.Add(element);
            }
            
        }

        public bool remove (T element)
        {
            bool flag = false;

            foreach(T item in this._elementos)
            {
                if(element.Equals(item))
                {
                    this._elementos.Remove(element);
                    flag = true;
                }
            }

            return flag;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("marca :"+this._marca);
            sb.AppendLine("capacidad :"+this._capacidad.ToString());
            foreach(T item in this._elementos)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }

    }
}
