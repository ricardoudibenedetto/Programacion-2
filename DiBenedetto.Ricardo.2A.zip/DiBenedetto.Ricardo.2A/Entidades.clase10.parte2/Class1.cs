using System;

namespace Entidades.clase10.parte2
{
    public class Class1
    {

    }
}
