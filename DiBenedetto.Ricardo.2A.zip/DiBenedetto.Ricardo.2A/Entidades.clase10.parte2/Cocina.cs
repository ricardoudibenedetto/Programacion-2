using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.clase10.parte2
{
    public class Cocina
    {
    int _codigo;
    bool _esIndustrial;
    double _precio;

    public int Codigo { get { return _codigo; } }
    public bool EsIndustrial { get { return _esIndustrial; } }
    public double Precio { get { return _precio; } }

    public Cocina(int codigo , double precio , bool esIndustrial)
    {
      this._precio = precio;
      this._esIndustrial = esIndustrial;
      this._codigo = codigo;
    }

    public static bool operator ==(Cocina c1, Cocina c2)
    {
      bool flag = false;
      if(c1.Codigo==c2.Codigo)
      {
        flag = true;
      }
      return flag;
    }

    public static bool operator !=(Cocina c1, Cocina c2)
    {
      return !(c1 == c2);
    }

    public override bool Equals(object obj)
    {
      bool flag = false;
      if (obj is Cocina && this == (Cocina)obj)
      {
        flag = true;
      }
      return flag;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("codigo :" + this.Codigo);
      sb.Append(" - precio : " + this.Precio);
      sb.AppendLine(" - es industrial? " + this.EsIndustrial);
      return sb.ToString();
    }

  }
}
