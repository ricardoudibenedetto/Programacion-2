using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public abstract class Auto : Vheiculo
    {
    protected string _patente;
    public Auto(double precio , string patente):base (precio)
    {
      this._patente = patente;
    }

    public void MostrarPatente()
    {
      Console.WriteLine(this._patente);
    }
    }
}
