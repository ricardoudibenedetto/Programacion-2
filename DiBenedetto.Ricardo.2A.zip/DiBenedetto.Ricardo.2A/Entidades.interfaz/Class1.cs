﻿using System;

namespace Entidades.interfaz
{
    public class Class1
    {
    }
}
