using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public class Deportivo : Auto , IAFIP
    {
    protected int _caballosFuerza;  

    public Deportivo(double precio, string patente, int hp):base(precio,patente)
    {
      this._caballosFuerza = hp;
      
    }

    public double CalcularImpuesto()
    {
      return this._precio * 0.28;
    }
  }
}
