using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public abstract class Vheiculo
    {
    protected double _precio;

    public void MostrarPrecio()
    {
      Console.WriteLine(this._precio);
    }

    public Vheiculo(double precio)
    {
      this._precio = precio;
    }
    }
}
