using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public interface IAFIP
    {
    double CalcularImpuesto();
    
    }
}
