using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public static class Gestion
    {
    public static double MostrarImpuestoNacional(IAFIP BienPunible)
    {
      return BienPunible.CalcularImpuesto();
    }
  }
}
