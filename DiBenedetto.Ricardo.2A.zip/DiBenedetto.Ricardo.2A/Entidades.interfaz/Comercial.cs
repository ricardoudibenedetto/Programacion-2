using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public class Comercial : Avion , IARBA
    {
    protected int _cantidadPasajeros;

    public Comercial(double precio, double velocidad, int cantPasaj):base(precio, velocidad)
    {
      this._cantidadPasajeros = cantPasaj;
    }

    double IARBA.CalcularImpuesto()
    {
      return this._precio * 0.25;
    }
  }
}
