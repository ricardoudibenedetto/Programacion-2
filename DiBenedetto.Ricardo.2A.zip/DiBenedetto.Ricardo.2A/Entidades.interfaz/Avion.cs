using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public class Avion : Vheiculo , IAFIP , IARBA
    {
    protected double _velocidadMaxima;
    public Avion (double precio, double VelMax):base(precio)
    {
      this._velocidadMaxima = VelMax;
      this._precio = precio + ((IAFIP)this).CalcularImpuesto();
    }

    double IAFIP.CalcularImpuesto()
    {
      return this._precio * 0.33;
    }

    double IARBA.CalcularImpuesto()
    {
      return this._precio * 0.27;
    }
  }
}
