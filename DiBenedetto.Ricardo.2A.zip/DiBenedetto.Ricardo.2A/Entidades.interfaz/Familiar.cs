using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.interfaz
{
    public class Familiar : Auto
    {
    protected int _cantAsientos;

    public Familiar(double precio , string patente , int cantAsiento):base(precio, patente)
    {
      this._cantAsientos = cantAsiento;
    }
    }
}
