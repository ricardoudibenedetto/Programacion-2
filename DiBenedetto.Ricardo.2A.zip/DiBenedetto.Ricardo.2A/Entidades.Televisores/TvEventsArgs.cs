using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Televisores
{
  public class TvEventsArgs : EventArgs
  {
    public DateTime fecha { get {return DateTime.Now; } }

  }
}
