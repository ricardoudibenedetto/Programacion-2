using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio01
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "ejercicio01";
      int num = 0;
      int acumulador = 0;
      int numMax = -9999999;
      int numMin = 99999999;
      float promedio;
      for(int i=0; i<5;i++)
      {
        Console.WriteLine("ingrese un numero");
        num = int.Parse(Console.ReadLine());
        if(i==0)
        {
          numMax = num;
          numMin = num;
        }
        else
        {
          if(num>numMax)
          {
            numMax = num;
          }
          if (num < numMin)
          {
            numMin = num;
          }
        }
        acumulador = acumulador + num;
        
      }
      promedio = (float)acumulador / 5;
      Console.WriteLine("\n\nEl valor maximo es: {0}\nel valor minimo es: {1}\nel promedio es: {2}",numMax,numMin,promedio);
      //Console.WriteLine(acumulador);
      Console.ReadKey();
    }
  }
}
