using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  class Sello
  {
    //ATRIBUTOS
    public static string mensaje;
    public static ConsoleColor color;

    //METODOS
    public static string Imprimir()
    {
      string cadena;

      if (Sello.TryParse(Sello.mensaje, out cadena))
      {
        Sello.mensaje = cadena;
        Sello.mensaje = ArmarFormatoMensaje();
      }
      else
        Console.Write("error mensaje vacio");
        
      
      
      return Sello.mensaje ;
    }

    public static void Borrar()
    {
      Sello.mensaje = "";
    }

    public static void ImprimirEnColor()
    {
      Console.BackgroundColor = Sello.color;
      Console.WriteLine(Sello.Imprimir());
      Console.BackgroundColor = ConsoleColor.Black;
    }
    private static string ArmarFormatoMensaje()
    {
      int caracteres;
      int i;
      string asterisco = "";
      string mensajeDecorado="";
      caracteres=Sello.mensaje.Length;
     
      for(i=0;i<caracteres+2;i++)
      {
        asterisco += "*";
      }

      asterisco += "\n";
      mensajeDecorado = asterisco + "*" + Sello.mensaje + "*\n" + asterisco;
      return mensajeDecorado;
    }

    private static bool TryParse(string a , out string b)
    {
      bool retornoAux = false;
      b = "";
      if(a.Length>0)
      {
        b = a;
        retornoAux = true;
      }
      return retornoAux;
    }

  }
}
