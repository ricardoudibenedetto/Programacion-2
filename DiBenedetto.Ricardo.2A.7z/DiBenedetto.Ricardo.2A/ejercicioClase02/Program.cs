using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace ejercicioClase02
{
  class Program
  {
    static void Main(string[] args)
    {
      Sello.mensaje = "hola";
      Sello.color = ConsoleColor.Cyan;
      Sello.ImprimirEnColor();
      Sello.mensaje = "como estas ?";
      Console.WriteLine(Sello.Imprimir());
      //Sello.Borrar();
      //Console.WriteLine(Sello.Imprimir());
      Console.ReadKey();
    }
  }
}
