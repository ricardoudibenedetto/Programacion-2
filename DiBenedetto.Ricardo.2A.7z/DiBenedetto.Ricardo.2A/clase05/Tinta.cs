using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase05
{
  class Tinta
  {
    #region atribute
    private ConsoleColor _color;
    private ETipoTinta _tipo;
    #endregion
    #region metodo
    public static string mostrar(Tinta objTinta)
    {
      string returnoAux = "--";

      if (!Object.Equals(objTinta, null))
        returnoAux = objTinta.mostrar();

      return returnoAux;

    }

    private string mostrar()
    {

      string retornoAux = _color + " - " + _tipo;
      
      return retornoAux;
    }
    #endregion
    #region Constructor
    public Tinta()
    {
      this._color = ConsoleColor.Blue;
      this._tipo = ETipoTinta.ConBrillito;
    }

    public Tinta(ConsoleColor colorParam) : this()
    {
      this._color = colorParam;
    }
    public Tinta(ETipoTinta tintaParam) : this()
    {
      this._tipo = tintaParam;
    }
    public Tinta(ETipoTinta tintaParam,ConsoleColor colorParam)
    {
      this._tipo = tintaParam;
      this._color = colorParam;
    }
    public Tinta(ConsoleColor colorParam, ETipoTinta tintaParam)
    {
      this._tipo = tintaParam;
      this._color = colorParam;
    }
    #endregion
    #region SOBRECARGA OP
    public static bool operator ==(Tinta t1 , Tinta t2 )
    {
      bool retorno=false;
      if(!Object.Equals(t1,null) && ! Object.Equals(t2, null))
      {
        if (t1._color == t2._color && t1._tipo == t2._tipo)
        {
          retorno = true;
        }
      }
      
      return retorno;
    }

    public static bool operator !=(Tinta t1, Tinta t2)
    {
      
      return !(t1==t2);

    }
    #endregion
  }
}
