using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase05
{
  class Tinta
  {
    #region atribute
    private ConsoleColor _color;
    private ETipoTinta _tipo;
    #endregion
    #region metodo
    public static string mostrar(Tinta objTinta)
    {

      return objTinta.mostrar();

    }

    private string mostrar()
    {
      return _color + " - " + _tipo;
    }
    #endregion
    #region Constructor
    public Tinta()
    {
      this._color = ConsoleColor.Blue;
      this._tipo = ETipoTinta.ConBrillito;
    }

    public Tinta(ConsoleColor colorParam) : this()
    {
      this._color = colorParam;
    }
    public Tinta(ETipoTinta tintaParam) : this()
    {
      this._tipo = tintaParam;
    }
    public Tinta(ETipoTinta tintaParam,ConsoleColor colorParam)
    {
      this._tipo = tintaParam;
      this._color = colorParam;
    }
    public Tinta(ConsoleColor colorParam, ETipoTinta tintaParam)
    {
      this._tipo = tintaParam;
      this._color = colorParam;
    }
    #endregion
    #region SOBRECARGA OP
    public static bool operator ==(Tinta t1 , Tinta t2 )
    {
      bool retorno=false;
      if(t1._color==t2._color && t1._tipo==t2._tipo)
      {
        retorno = true;
      }
      return retorno;
    }

    public static bool operator !=(Tinta t1, Tinta t2)
    {
      
      return !(t1==t2);

    }
    #endregion
  }
}
