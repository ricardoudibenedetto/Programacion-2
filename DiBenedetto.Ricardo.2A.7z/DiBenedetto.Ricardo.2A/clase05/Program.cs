using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clase05;
namespace clase05
{
  class Program
  {
    static void Main(string[] args)
    {
      ConsoleColor color = ConsoleColor.Cyan;
      ETipoTinta tipo = ETipoTinta.China;
      Tinta tinta = new Tinta(color,tipo);

      Console.WriteLine(Tinta.mostrar(tinta));
      Console.ReadKey();
    }
  }
}
