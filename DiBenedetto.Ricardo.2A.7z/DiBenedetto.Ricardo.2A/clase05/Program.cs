using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clase05;
namespace clase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Tinta tinta = new Tinta(ConsoleColor.Cyan,ETipoTinta.China);
     
      //Console.WriteLine(Tinta.mostrar(tinta));

      Pluma Pluma1 = new Pluma("pelican",5);
      //for(int i=0;i<10;i++)
      //Pluma1 += tinta;

      //for (int i = 0; i < 3; i++)
      //  Pluma1 -= tinta;

      Console.WriteLine(Pluma1);
      Console.ReadKey();
    }
  }
}
