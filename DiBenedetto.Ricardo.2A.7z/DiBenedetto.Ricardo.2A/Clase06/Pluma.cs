using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase05
{
  class Pluma
  {
    #region ATRIBUTOS
    private string _marca;
    private int _cantidad;
    private Tinta _tinta;

    #endregion
    #region METODOS
    private string mostrar()
    {
      return _marca + " " + _cantidad + " " + Tinta.mostrar(_tinta);
    }

    public static implicit operator string(Pluma a)
    {

      return a.mostrar();
    }
    #endregion
    #region CONSTRUCTOR
    public Pluma()
    {
      this._marca = "sin marca";
      this._cantidad = 0;
      this._tinta = null;
    }

    public Pluma(string marcaParam):this()
    {
      this._marca = marcaParam ;
    }

    public Pluma(string marcaParam , int cantidad) : this(marcaParam)
    {
      this._cantidad = cantidad;
    }


    public Pluma(string marcaParam, int cantidad, Tinta tintaParam) :this(marcaParam , cantidad)
    {
     
      this._tinta = tintaParam;
    }

    #endregion

    #region CONSTRUCTOR
    public static bool operator ==(Pluma p1, Tinta t2)
    {
      bool retorno = false;

      if (p1._tinta == t2)
      {
        retorno = true;
      }
      return retorno;
    }
    public static bool operator !=(Pluma p1, Tinta t2)
    {

      return !(p1 == t2);

    }


    public static Pluma operator +(Pluma pl, Tinta tint)
    {
      
      if(pl==tint)
      {
        pl._cantidad += 10;
        if (pl._cantidad > 100)
        {
          pl._cantidad -= 10;
        }
      }
      return pl;
    }

    public static Pluma operator -(Pluma pl, Tinta tint)
    {

      if (pl == tint)
      {
        pl._cantidad -= 15;
        if (pl._cantidad < 0)
        {
          pl._cantidad += 15;
        }
      }
      return pl;
    }


    #endregion
  }

}
