using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "ejercicio03";
      int num;
      Console.Write("ingrese un numero: ");
      Console.ReadLine(num);
    }
  }
}
