﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Manual : Libro
    {
        public ETipo tipo;

        public Manual (string titulo,float precio,string nombre,string apellido , ETipo tipo):base(precio,titulo,nombre,apellido)
        {
            this.tipo = tipo;
        }

        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine((string)this);
            sb.AppendLine("tipo " + this.tipo);
            sb.AppendLine(" " + this.mostrar());

            return sb.ToString();
        }

        public static bool operator ==(Manual a, Manual b)
        {
            
            bool returnAux = false;
            if (a==b && a.tipo== b.tipo)
            {
                returnAux = true;
            }
            return returnAux;
        }
        public static bool operator !=(Manual a, Manual b)
        {
            return !(a == b);
        }

        public static implicit operator float(Manual a)
        {
            return a._precio;
        }
    }
}
