﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        int _capacidad;
        List<Libro> _libros;

        public double PrecioDeManuales {
            get
            { return this.ObtenerPrecio(ELibro.Manual);
            }
        }
        public double PrecioDeNovelas {
            get
            { return this.ObtenerPrecio(ELibro.Novela);
            }
        }
        public double PrecioTotal {
            get
            {
                return this.ObtenerPrecio(ELibro.Ambos);
            }
        }

        private Biblioteca()
        {
            this._libros = new List<Libro>();
        }

        

        private Biblioteca (int capacidad):this()
        {
            this._capacidad = capacidad;
        }

        public static implicit operator Biblioteca(int capacidad)
        {
            return new Biblioteca(capacidad);
        }


        public static Biblioteca operator +(Biblioteca bibli, Libro lib)
        {
            foreach (Libro item in bibli._libros)
            {
                if (item == lib && (bibli._capacidad > bibli._libros.Count))
                {
                    return bibli;
                }


            }
            bibli._libros.Add(lib);
            return bibli;
        }

        private double ObtenerPrecio(ELibro tipoLibro)
        {
            double precioNov = 0;
            double precioManu = 0;

            double precio = 0;

            foreach (Libro item in this._libros)
            {
                if (item is Novela)
                {
                    precioNov = (Novela )item;
                    break;
                }
                else if (item is Manual)
                {
                    precioManu = (Manual)item;
                    break;
                }
            }

            switch (tipoLibro)
            {
                case ELibro.Manual:
                    precio = precioManu;
                    break;

                case ELibro.Novela:
                    precio = precioNov;
                    break;
                case ELibro.Ambos:
                    precio = precioManu + precioNov;
                    break;
            }
            return precio;
        }

        public static string Mostrar(Biblioteca e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Capacidad biblioteca: ");
            sb.AppendLine(e._capacidad.ToString());
            sb.Append("Total por Manuales: ");
            sb.AppendLine(e.PrecioDeManuales.ToString());
            sb.Append("Total por Novelas: ");
            sb.AppendLine(e.PrecioDeNovelas.ToString());
            sb.Append("Total : ");
            sb.AppendLine(e.PrecioTotal.ToString());
            sb.AppendLine("Lista de Libros ");
            foreach (Libro item in e._libros)
            {
                if (item is Manual)
                {
                    sb.AppendLine(((Manual)item).mostrar());
                    sb.Append("");
                }
                else if (item is Novela)
                {
                    sb.AppendLine(((Novela)item).mostrar());
                    

                }


            }

            return sb.ToString();
        }



        public static bool operator ==(Biblioteca Bibli, Libro lib)
        {
            bool returnAux = false;
  
            foreach (Libro i in Bibli._libros)
            {
                if (i == lib)
                {
                    returnAux = true;
                    break;
                }
            }
            return returnAux;


        }
        public static bool operator !=(Biblioteca bibli, Libro lib)
        {
            return !(bibli == lib);
        }

    }
}
