﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Novela : Libro
    {
        public EGenero genero;

        public Novela(string titulo, float precio, Autor autor, EGenero genero) : base(titulo , autor,precio)
        {
            this.genero = genero;
        }

        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine((string)this);
            sb.AppendLine("Genero " + this.genero.ToString());
            return sb.ToString();
         
        }


        public static bool operator ==(Novela a, Novela b)
        {

            bool returnAux = false;
            if (a == b && a.genero == b.genero)
            {
                returnAux = true;
            }
            return returnAux;
        }

        public static bool operator !=(Novela a , Novela b)
        {
            return !(a == b);
        }


        public static implicit operator double(Novela a)
        {
            return a._precio;
        }


    }




}
