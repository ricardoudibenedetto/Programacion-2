﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Autor
    {
        string apellido;
        string nombre;
        //constructor
        public Autor (string nombre, string apellido)
        {
            this.apellido = apellido;
            this.nombre = nombre;
        }
        

        //sobrecarga 
        public static bool operator ==(Autor a1, Autor a2)
        {
            bool returnAux = false;
            if ( string.Compare(a1.nombre ,a2.nombre )==0 && string.Compare(a1.apellido,a2.apellido)==0)
            {
                returnAux = true;
            }
            return returnAux;
        }
        public static bool operator !=(Autor a1, Autor a2)
        {
            return !(a1 == a2);
        }

        public static implicit operator string(Autor a1)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("autor : " + a1.nombre + " " + a1.apellido);
            return sb.ToString();
        }

    }
}
