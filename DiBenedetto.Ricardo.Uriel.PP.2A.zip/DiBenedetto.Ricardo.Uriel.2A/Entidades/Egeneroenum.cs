﻿public enum EGenero
{
    Accion,
    Romantica,
    CienciaFiccion
}