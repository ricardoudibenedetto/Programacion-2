﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        static protected Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;

        static Libro() { 
          

        }

        public Libro(string titulo ,Autor autor , float precio)
        {
            this._titulo = titulo;
            this._autor = autor;
            this._precio = precio;
            

        }
        public Libro(float precio, string titulo, string nombre, string apellido):this(titulo,new Autor(nombre ,apellido), precio)
        {

        }

        public int CantidadDePaginas
        {
            get {
                _generadorDePaginas = new Random();
                this._cantidadDePaginas = _generadorDePaginas.Next(10, 580);
                return this._cantidadDePaginas;
                }
        }

        private static string mostrar(Libro l)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine( l._autor);
            sb.AppendLine("titulo: " + l._titulo);
            sb.AppendLine("cantidad de paginas : " + l._cantidadDePaginas);
            sb.AppendLine("precio: " + l._precio);
            return sb.ToString();
        }
        public static explicit operator string(Libro L)
        {
            return Libro.mostrar(L);
        }

        public static bool operator ==(Libro L1, Libro l2)
        {
            bool returnAux = false;
            if (string.Compare(L1._titulo, l2._titulo) == 0 && L1._autor==l2._autor)
            {
                returnAux = true;
            }
            return returnAux;
        }

        public static bool operator !=(Libro L1, Libro l2)
        {
            return !(L1 == l2);
        }
    }
}
